export const getCurrentPath = () => window.location.pathname
